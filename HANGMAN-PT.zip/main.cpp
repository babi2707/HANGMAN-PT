#include <iostream>
#include <string>
#include <iomanip>
#include <ctime>
#include <cstdlib>
using namespace std;

const int max_trials = 6;
int letterFill (char, string, string&);

int main()
{
  string name;
  char letter;
  int wrong_guess = 0;
  string word;
  string countrywords [41] = { "argentina", "australia", "brazil", "belgium", "canada", "china", "chile", "colombia", "denmark", "ecuador", "egypt", "france", "germany", "greece", "haiti", "india", "italy", "japan", "kenya", "lebanon", "madagascar", "maldives", "mexico", "nepal", "new zealand", "nigeria", "panama", "paraguay", "peru", "portugal", "russia", "romania", "saudi arabia", "senegal", "sweden", "switzerland", "turkey", "uruguay", "venezuela", "vietnam", "zambia" };

	srand(time(NULL));
	int n=rand()% 41;
	word=countrywords[n];

  string unknown(word.length(),'-');

  cout << "\n\t\tInstructions: " << endl;
  cout << "1- Guess a letter." << endl;
  cout << "\tIf you guess a right letter, nothing happens with your \nhangman and your letter shows up in the secret word. " << endl;
  cout << "\tIf your letter is not in the word, you start to \nbe hanged, and when you make 6 mistakes, you will be \ncompletely hanged and lose the game. " << endl;
  cout << "3- Your goal is to make as less mistakes as possible \nand guess the word before you are completely hanged. " << endl;
  cout << "\n\t ___________________________________________" << endl;

  while (wrong_guess < max_trials)
  {
    cout << "\n\t\t" << unknown << endl;

    cout << "Guess a letter: ";
    cin >> letter;

    if (letterFill(letter, word, unknown) == 0)
    {
      cout << "\nOh no! This word doesn't have the letter " << letter << "." << endl;
      wrong_guess++;
      cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
      cout << "\n\t _______________________________" << endl;
    }

    else 
    {
      cout << "\nUhull! This word has the letter " << letter << "." << endl;
      cout << "You have " << max_trials - wrong_guess << " wrong guesses left. " << endl;
      cout << "\n\t _______________________________" << endl;
    }

    if (word == unknown)
    {
      cout << "\n\n\t\t" << word << endl;
      cout << "\nYay!! You got the word!! Nice job!!" << endl;
      break;
    }

  }

  if (wrong_guess == max_trials)
  {
    cout << "\n Oh no! The number of wrong guesses is over! \n You lost! Maybe you will have better luck next time!" << endl;
    cout << "\n The word was  " << word << endl;
  }

  cout << "Thank you for playing my Hangman Game!! See you next time!" << endl;

	return 0;
}

int letterFill (char guess, string secretword, string &guessword)
{
	int matches = 0;
	int len=secretword.length();
	for (int i = 0; i< len; i++)
	{
		if (guess == guessword[i])
      return 0;
		if (guess == secretword[i])
		{
			guessword[i] = guess;
			matches++;
		}
  }
  return matches;
}